<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(268435456=>array(285212671,'US'));
